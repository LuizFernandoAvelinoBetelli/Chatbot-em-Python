import random
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from wordcloud import WordCloud
from PIL import ImageTk
import tkinter as tk
from tkinter import scrolledtext


# Inicializar modelo SpaCy e baixar dados
nlp = spacy.load('pt_core_news_md')

# Base de conhecimento com perguntas e respostas
knowledge_base = {
    "O que é um jogo multiplayer online?": "Um jogo multiplayer online permite que vários jogadores joguem juntos, conectados pela internet, seja cooperativamente ou competindo uns contra os outros.",
    "O que significa o termo 'FPS' em jogos?": "FPS pode se referir a dois significados em jogos: 'First-Person Shooter' (jogo de tiro em primeira pessoa) ou 'Frames per Second' (quadros por segundo), que mede a taxa de atualização de um jogo.",
    "O que é um jogo de mundo aberto?": "Um jogo de mundo aberto permite que os jogadores explorem livremente o ambiente do jogo, sem restrições lineares, oferecendo liberdade para seguir a história ou realizar missões secundárias no seu próprio ritmo.",
    "O que é o jogo Fortnite?": "Fortnite é um jogo de battle royale em que 100 jogadores lutam entre si até que apenas um sobreviva, com a possibilidade de construir estruturas e coletar recursos durante a partida.",
    "O que é o jogo Minecraft?": "Minecraft é um jogo de construção em mundo aberto, onde os jogadores podem explorar, extrair recursos, criar construções e sobreviver contra monstros, tudo em um ambiente gerado proceduralmente.",
    "O que significa MOBA?": "MOBA significa Multiplayer Online Battle Arena. É um gênero de jogos em que duas equipes competem entre si para destruir a base do time adversário, como em jogos como League of Legends e Dota 2.",
    "O que é um jogo roguelike?": "Um jogo roguelike é caracterizado por mapas gerados aleatoriamente, morte permanente e jogabilidade baseada em turnos. Exemplos incluem The Binding of Isaac e Hades.",
    "O que é um jogo sandbox?": "Um jogo sandbox é um tipo de jogo que oferece aos jogadores uma grande liberdade para explorar, construir e interagir com o mundo de maneiras não lineares, como em Minecraft ou Garry's Mod.",
    "O que é o jogo The Legend of Zelda: Breath of the Wild?": "The Legend of Zelda: Breath of the Wild é um jogo de ação e aventura em mundo aberto, onde os jogadores controlam Link em uma jornada para derrotar o vilão Calamity Ganon e salvar o reino de Hyrule.",
    "O que é o jogo The Witcher 3?": "The Witcher 3: Wild Hunt é um RPG de ação em mundo aberto, no qual os jogadores controlam Geralt de Rivia, um caçador de monstros, enquanto navegam por um mundo cheio de escolhas e consequências.",
    "O que significa RPG em jogos?": "RPG significa Role-Playing Game, ou Jogo de Interpretação de Papéis. Neste tipo de jogo, os jogadores assumem o papel de personagens em um mundo fictício, muitas vezes com elementos de progressão de níveis e uma história profunda.",
    "O que é o jogo Dark Souls?": "Dark Souls é um jogo de ação e RPG conhecido por sua dificuldade elevada, combates desafiadores e um mundo sombrio cheio de inimigos poderosos e mecânicas de morte e ressurgimento.",
    "O que significa DLC em jogos?": "DLC significa Downloadable Content, ou Conteúdo para Download. São expansões ou pacotes adicionais de conteúdo lançados pelos desenvolvedores após o jogo principal, adicionando novas funcionalidades, missões ou itens.",
    "Me indique um jogo": "Se você gosta de jogos de ação em mundo aberto, recomendo The Witcher 3: Wild Hunt. Para algo mais casual e criativo, Minecraft é uma ótima escolha.",
    "Me indique um jogo de tiro": "Para jogos de tiro em primeira pessoa, sugiro Call of Duty: Modern Warfare ou Apex Legends, ambos com ótima jogabilidade e modos multiplayer.",
    "Me indique um jogo de RPG": "Se você gosta de RPGs, experimente The Elder Scrolls V: Skyrim ou Divinity: Original Sin II, que oferecem mundos expansivos e uma narrativa envolvente.",
    "Me indique um jogo de corrida": "Se você gosta de jogos de corrida, experimente Forza Horizon 5, um dos melhores no gênero de mundo aberto com corridas dinâmicas e personalizações.",
    "Me indique um jogo de estratégia": "Para jogos de estratégia, Civilization VI é uma ótima opção para quem gosta de construir e expandir civilizações ao longo da história.",
    "Me indique um jogo multiplayer online": "Se você procura um jogo multiplayer online, Fortnite ou Overwatch são boas opções, ambos com modos competitivos e cooperativos.",
    "Me indique um jogo de terror": "Se você gosta de jogos de terror, experimente Resident Evil Village ou Phasmophobia, ambos com uma atmosfera assustadora e mecânicas envolventes.",
    "Me indique um jogo de aventura": "Se você prefere jogos de aventura, The Legend of Zelda: Breath of the Wild é uma recomendação imperdível, com um vasto mundo aberto para explorar."
}

# Palavras de boas-vindas
welcome_words_input = ['hey', 'olá', 'oi', 'oie']
welcome_words_output = ['Hey!', 'Olá, seja bem-vindo!', 'Oie, seja bem-vindo!']

# Respostas baseadas no sentimento
positive_responses = [
    "Que coisa boa! Eu fico muito feliz em receber este feedback.",
    "Que ótimo! Isso me deixa muito animado."
]
negative_responses = [
    "Sinto muito pelo seu sentimento, posso te ajudar em alguma coisa?",
    "Que pena que você se sente assim. Posso fazer algo para ajudar?"
]

# Palavras base para sentimentos positivos e negativos e seus vetores
positive_words = ["feliz", "alegria", "ótimo", "excelente", "maravilhoso", "adoro", "amo"]
negative_words = ["triste", "raiva", "péssimo", "horrível", "odeio", "detesto", "insuportável"]

positive_tokens = [nlp(word) for word in positive_words]
negative_tokens = [nlp(word) for word in negative_words]

# Função para analisar o sentimento com base em similaridade
def analyze_sentiment(text, threshold=0.6):
    doc = nlp(text.lower())  # Processa o texto de entrada
    positive_score = 0
    negative_score = 0

    for token in doc:
        if token.has_vector and token.is_alpha:
            # Calcular similaridade com palavras positivas
            pos_sim = max(token.similarity(pos_token) for pos_token in positive_tokens)
            # Calcular similaridade com palavras negativas
            neg_sim = max(token.similarity(neg_token) for neg_token in negative_tokens)

            # Adicionar pontuações acima do threshold
            if pos_sim > threshold:
                positive_score += pos_sim
            if neg_sim > threshold:
                negative_score += neg_sim

    # Determinar o sentimento predominante
    if positive_score > negative_score:
        return "positive"
    elif negative_score > positive_score:
        return "negative"
    else:
        return "neutral"

# Função de boas-vindas
def welcome_message(text):
    for word in text.split():
        if word.lower() in welcome_words_input:
            return random.choice(welcome_words_output)
    return None

# Função para pré-processar texto
def preprocessing(sentence):
    tokens = [token.text for token in nlp(sentence.lower()) 
              if not (token.is_stop or token.is_punct or token.is_space)]
    return ' '.join(tokens)

# Função para gerar a nuvem de palavras
def generate_wordcloud(response):
    wordcloud = WordCloud(width=400, height=200, background_color="white").generate(response)
    return wordcloud

# Função para atualizar a nuvem de palavras na interface
def update_wordcloud(wordcloud):
    img = wordcloud.to_image()  # Converte a nuvem para uma imagem
    img_tk = ImageTk.PhotoImage(img)
    wordcloud_label.config(image=img_tk)
    wordcloud_label.image = img_tk  # Mantém referência para exibição

# Função para responder perguntas usando similaridade de cosseno
def answer(user_text, threshold=0.6):
    questions = list(knowledge_base.keys())
    cleaned_questions = [preprocessing(question) for question in questions]
    user_text = preprocessing(user_text)
    cleaned_questions.append(user_text)

    tfidf = TfidfVectorizer()
    x_questions = tfidf.fit_transform(cleaned_questions)
    similarity = cosine_similarity(x_questions[-1], x_questions[:-1])

    similar_question_index = similarity.argsort()[0][-1]
    max_similarity = similarity[0][similar_question_index]

    if max_similarity >= threshold:
        response = knowledge_base[questions[similar_question_index]]
        wordcloud = generate_wordcloud(preprocessing(response))
        update_wordcloud(wordcloud) 
        return response
    else:
        return "Desculpe, não tenho informações sobre isso."

# Função para processar a entrada do usuário e exibir resposta
def process_input():
    user_text = user_input.get()
    if user_text.lower() == 'sair':
        window.quit()
    else:
        # Analisar sentimento
        sentiment = analyze_sentiment(user_text)
        if sentiment == "positive":
            response = random.choice(positive_responses)
        elif sentiment == "negative":
            response = random.choice(negative_responses)
        else:
            # Processar como pergunta normal
            welcome_msg = welcome_message(user_text)
            if welcome_msg:
                response = welcome_msg
            else:
                response = answer(user_text)

        # Exibir no chat
        chat_area.insert(tk.END, "Você: " + user_text + "\n")
        chat_area.insert(tk.END, "Chatbot: " + response + "\n")
        user_input.delete(0, tk.END)

# Criando a interface Tkinter
window = tk.Tk()
window.title("Chatbot com Análise de Sentimentos")
window.geometry("600x700")

# Área de texto para exibir o chat
chat_area = scrolledtext.ScrolledText(window, wrap=tk.WORD, height=20, width=70)
chat_area.pack(pady=10)
chat_area.insert(tk.END, "Chatbot: Olá! Sou um chatbot e posso responder suas perguntas sobre jogos.\n")

# Campo de entrada para o usuário
user_input = tk.Entry(window, width=60)
user_input.pack(pady=10)

# Botão para enviar a mensagem
send_button = tk.Button(window, text="Enviar", command=process_input)
send_button.pack()

# Espaço para a nuvem de palavras
wordcloud_label = tk.Label(window)
wordcloud_label.pack(pady=20)

# Inicia a interface
window.mainloop()