import subprocess
import sys

# Função para instalar pacotes
def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Instalar pacotes necessários
def setup_environment():
    print("Instalando pacotes necessarios...")
    install("spacy")
    install("nltk")
    install("scikit-learn")
    install("nltk")
    install("wordcloud")
    install("textblob")
    install("pillow")
    install("langdetect")
    
    print("Baixando modelo SpaCy...")
    subprocess.check_call([sys.executable, "-m", "spacy", "download", "pt_core_news_md"])

    print("Instalacao concluida!")

if __name__ == "__main__":
    setup_environment()